--
-- PostgreSQL database dump
--

\restrict OUoisba6MNaEEK3l8rV7TLaFXc8PJeIh4FQjAnG9vgg14K6gxaMXfIOE7LgF3lQ

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    prix double precision NOT NULL,
    categorie character varying(50) NOT NULL,
    image character varying(200)
);


ALTER TABLE public.menu OWNER TO postgres;

--
-- Name: menu_document_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_document_pages (
    id integer NOT NULL,
    document_id integer NOT NULL,
    numero integer NOT NULL,
    image bytea NOT NULL
);


ALTER TABLE public.menu_document_pages OWNER TO postgres;

--
-- Name: menu_document_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_document_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_document_pages_id_seq OWNER TO postgres;

--
-- Name: menu_document_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_document_pages_id_seq OWNED BY public.menu_document_pages.id;


--
-- Name: menu_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_documents (
    id integer NOT NULL,
    nom_fichier character varying(200) NOT NULL,
    contenu bytea NOT NULL,
    date_upload timestamp without time zone
);


ALTER TABLE public.menu_documents OWNER TO postgres;

--
-- Name: menu_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_documents_id_seq OWNER TO postgres;

--
-- Name: menu_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_documents_id_seq OWNED BY public.menu_documents.id;


--
-- Name: menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_id_seq OWNER TO postgres;

--
-- Name: menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_id_seq OWNED BY public.menu.id;


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservations (
    id integer NOT NULL,
    reference character varying(30) NOT NULL,
    groupe_reference character varying(20),
    nom character varying(100) NOT NULL,
    email character varying(120) NOT NULL,
    telephone character varying(20),
    date character varying(20) NOT NULL,
    heure character varying(10) NOT NULL,
    personnes integer NOT NULL,
    message text,
    statut character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.reservations OWNER TO postgres;

--
-- Name: reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reservations_id_seq OWNER TO postgres;

--
-- Name: reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reservations_id_seq OWNED BY public.reservations.id;


--
-- Name: menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu ALTER COLUMN id SET DEFAULT nextval('public.menu_id_seq'::regclass);


--
-- Name: menu_document_pages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_document_pages ALTER COLUMN id SET DEFAULT nextval('public.menu_document_pages_id_seq'::regclass);


--
-- Name: menu_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_documents ALTER COLUMN id SET DEFAULT nextval('public.menu_documents_id_seq'::regclass);


--
-- Name: reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations ALTER COLUMN id SET DEFAULT nextval('public.reservations_id_seq'::regclass);


--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu (id, nom, description, prix, categorie, image) FROM stdin;
\.


--
-- Data for Name: menu_document_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_document_pages (id, document_id, numero, image) FROM stdin;
\.


--
-- Data for Name: menu_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_documents (id, nom_fichier, contenu, date_upload) FROM stdin;
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservations (id, reference, groupe_reference, nom, email, telephone, date, heure, personnes, message, statut, created_at) FROM stdin;
\.


--
-- Name: menu_document_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_document_pages_id_seq', 1, true);


--
-- Name: menu_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_documents_id_seq', 1, true);


--
-- Name: menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_id_seq', 1, true);


--
-- Name: reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reservations_id_seq', 35, true);


--
-- Name: menu_document_pages menu_document_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_document_pages
    ADD CONSTRAINT menu_document_pages_pkey PRIMARY KEY (id);


--
-- Name: menu_documents menu_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_documents
    ADD CONSTRAINT menu_documents_pkey PRIMARY KEY (id);


--
-- Name: menu menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu
    ADD CONSTRAINT menu_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_reference_key UNIQUE (reference);


--
-- Name: menu_document_pages menu_document_pages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_document_pages
    ADD CONSTRAINT menu_document_pages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.menu_documents(id);


--
-- PostgreSQL database dump complete
--

\unrestrict OUoisba6MNaEEK3l8rV7TLaFXc8PJeIh4FQjAnG9vgg14K6gxaMXfIOE7LgF3lQ

